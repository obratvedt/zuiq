package com.example.oyvin.zuiq.sprites;

import sheep.game.Sprite;
import sheep.graphics.Image;

public class Logo extends Sprite {

    public Logo(Image image){
        super(image);
        setScale(0.2f, 0.2f);
    }
}

